# E-Commerce Website

Identify and resolve errors in the E-Commerce website codebase to ensure optimal functionality and user experience.

## How to Run

1. Install Live Server extension in your VSCode.
2. Right-click on index.html and select "Open with Live Server".
3. The website will launch in your default web browser.
