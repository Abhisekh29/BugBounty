# User Data Presentation

## Objective of the code
The objective of this program is to retrieve and display data of a random user. Upon running the code the user will be prompted to search for a user using user ID. Based on the user input, search for the corresponding ID and return the data.

## Prerequisites
- **Programming Language**: Python (or another language, depending on your implementation).

## Guidelines - 
- Run the code and identify the bugs. Then fix the bugs you have found.