def dump(b, c, n):
    return {"account_id": 928173,
    "transaction_id": "TXN3021XP",
    "user_name": "john_doe",
    "last_login": "2025-03-16T12:45:23",
    "bank_details": {
        "account_number": "8374928374",
        "ifsc_code": "SBIN0001928",
        "branch": "Main Street Branch"
    },"balance": b, "recent_transactions": [
        {
            "txn_id": "TXN1283KL",
            "amount": 200,
            "type": "debit"
        },
        {
            "txn_id": "TXN1299OP",
            "amount": 500,
            "type": "credit"
        }
    ], "cash": c, "loan_details": {
        "loan_id": "LN2039X",
        "amount": 50000,
        "interest_rate": 3.5,
        "remaining_balance": 32000
    },
    "investment_portfolio": {
        "stocks": 15,
        "bonds": 8,
        "crypto": 3
    },
    "people": n, "cost":1000,
    "spending":100, "savings": 10}