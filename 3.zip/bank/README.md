# User Data Presentation

# Important Notice

**PLEASE REFRAIN FROM MODIFYING ANY FILES THAT ARE NOT PYTHON SOURCE FILES.**  
Unauthorized changes to non-Python files could disrupt the proper functioning of the code. Only modify Python source files unless absolutely necessary.

Thank you for your understanding and cooperation!


## Objective of the code
The objective of this program is to simulate a survival game situation. 
- The user is given a starting bank balance.
- The user can withdraw money from the bank to receive cash in hand.
- The user spends the cash to buy supplies for people in his crew.
- After a certain point, once the user has bought supplies for a specific number of people, the bank balance runs out and the game ends.

## Objective of the participant
- Find a way to buy supplies for more people than the predetermined number.
- Ensure that the game logic is correct.

## Prerequisites
- **Programming Language**: Python (or another language, depending on your implementation).

## WARNING !!!
DO NOT TOUCH FILES THAT ARE NOT PYTHON SOURCE FILES. UNAUTHORIZED UPDATION OF THOSE FILES WILL RESULT IN THE CODES NOT WORKING PROPERLY.
 
## NOTE
Use the reset_data.py file to reset the stored data to it's original state.
Run reset_data.py once you find the bug and want to work on the solution.