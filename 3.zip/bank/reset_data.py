import json
from storage import dump
DATA_FILE = 'bank.json'
def load_data():
    try:
        with open(DATA_FILE, 'r') as file:
            data = json.load(file)
            return data.get("balance", 0), data.get("cash", 0), data.get("people", 0)
    except (FileNotFoundError, json.JSONDecodeError):
        return 1000, 0, 0
def save_data():
    with open(DATA_FILE, 'w') as file:
        json.dump(dump(balance, cash, people), file, indent=4)
balance, cash, people = load_data()
def reset():
    global balance, cash, people
    balance = 1000
    cash = 0
    people = 0
    save_data()
reset()