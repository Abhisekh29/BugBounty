from operate import withdraw, check_balance, buy_supplies, res
def bank_system():
    while True:
        print("\nBUY SUPPLIES!!!")
        print("\n-------------------\n--- Bank System ---\n-------------------\n")
        print("1. Withdraw Money")
        print("2. Check Balance")
        print("3. Buy Supplies")
        print("4. Exit\n")
        choice = input("Choose an option: ")
        if choice == '1':
            amount = int(input("Enter amount to withdraw: "))
            withdraw(amount)
        elif choice == '2':
            check_balance()
        elif choice == '3':
            number = int(input("Enter number of people to buy supplies for: "))
            buy_supplies(number*100)
        elif choice == '4':
            break
        else:
            print("Invalid choice. Try again.")
        res()
bank_system()
