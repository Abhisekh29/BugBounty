import json
from storage import dump
DATA_FILE = 'bank.json'
def load_data():
    try:
        with open(DATA_FILE, 'r') as file:
            data = json.load(file)
            return data.get("balance", 0), data.get("cash", 0), data.get("people", 0)
    except (FileNotFoundError, json.JSONDecodeError):
        return 1000, 0, 0
def save_data():
    with open(DATA_FILE, 'w') as file:
        json.dump(dump(balance, cash, people), file, indent=4)
balance, cash, people = load_data()
def withdraw(amount):
    global balance, cash
    if balance - amount >= 0:
        balance -= amount
        cash += abs(amount)
        print(f"${amount} withdrawn successfully. Cash in hand: ${cash}")
        save_data()
    else:
        print("Insufficient balance.")
def check_balance():
    global balance, cash
    print(f"\nBank Balance: ${balance}")
    print(f"Cash in Hand: ${cash}")
def buy_supplies(cost):
    global cash, people
    if cash - cost >= 0:
        cash -= cost
        people += cost//100
        print(f"Bought supplies worth ${cost}. Remaining cash: ${cash}")
        save_data()
    else:
        print("Not enough cash to buy supplies.")
def res():
    global people
    if people > 10:
        print("Bug found!")
    else:
        return